<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_6d5c5ed80404d7fba4e1e84732c2405e12b62075cf22057119f921c5a4684cd7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_903bfb81ec8f643fc2fe0def1238d7e27dd625b8479a4364165b9c319aa07d97 = $this->env->getExtension("native_profiler");
        $__internal_903bfb81ec8f643fc2fe0def1238d7e27dd625b8479a4364165b9c319aa07d97->enter($__internal_903bfb81ec8f643fc2fe0def1238d7e27dd625b8479a4364165b9c319aa07d97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_903bfb81ec8f643fc2fe0def1238d7e27dd625b8479a4364165b9c319aa07d97->leave($__internal_903bfb81ec8f643fc2fe0def1238d7e27dd625b8479a4364165b9c319aa07d97_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
