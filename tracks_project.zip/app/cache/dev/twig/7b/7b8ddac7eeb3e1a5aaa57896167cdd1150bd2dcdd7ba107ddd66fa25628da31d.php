<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_ad758b74fa664d68a566c6d334987e21130102cda913d57cc218c3a61a9e1ca0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d040cca9136cba575916b36df0ab01df360c5503d8b0e2f26afd9f07a8f4ae46 = $this->env->getExtension("native_profiler");
        $__internal_d040cca9136cba575916b36df0ab01df360c5503d8b0e2f26afd9f07a8f4ae46->enter($__internal_d040cca9136cba575916b36df0ab01df360c5503d8b0e2f26afd9f07a8f4ae46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_d040cca9136cba575916b36df0ab01df360c5503d8b0e2f26afd9f07a8f4ae46->leave($__internal_d040cca9136cba575916b36df0ab01df360c5503d8b0e2f26afd9f07a8f4ae46_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
