<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_3fbbdf77a460acd1cf508fe432fca1a85c89b940687627fedc3b55b9c134ab98 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2951e272e946ff5ca34c471b78308adeaf15fcae21b98f39a7a6af11b1365f30 = $this->env->getExtension("native_profiler");
        $__internal_2951e272e946ff5ca34c471b78308adeaf15fcae21b98f39a7a6af11b1365f30->enter($__internal_2951e272e946ff5ca34c471b78308adeaf15fcae21b98f39a7a6af11b1365f30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_2951e272e946ff5ca34c471b78308adeaf15fcae21b98f39a7a6af11b1365f30->leave($__internal_2951e272e946ff5ca34c471b78308adeaf15fcae21b98f39a7a6af11b1365f30_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
