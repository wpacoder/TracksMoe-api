<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_44378cb401d0fc061df9da58c55b71707b52e898285cd5c9fe14d162cf557d4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c216017e7693d214509d9d4e689d8db5a4954bfd85294d483af7cb545e8286cd = $this->env->getExtension("native_profiler");
        $__internal_c216017e7693d214509d9d4e689d8db5a4954bfd85294d483af7cb545e8286cd->enter($__internal_c216017e7693d214509d9d4e689d8db5a4954bfd85294d483af7cb545e8286cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_c216017e7693d214509d9d4e689d8db5a4954bfd85294d483af7cb545e8286cd->leave($__internal_c216017e7693d214509d9d4e689d8db5a4954bfd85294d483af7cb545e8286cd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
