<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_ea20ac30cb025a7e70b1112b1d1ef5c3b92193049e619686fe5c3387e7d27694 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2909018ece19f4bbf41657f9e44db7e8482b22580171cc3fe6fdff189ccc2516 = $this->env->getExtension("native_profiler");
        $__internal_2909018ece19f4bbf41657f9e44db7e8482b22580171cc3fe6fdff189ccc2516->enter($__internal_2909018ece19f4bbf41657f9e44db7e8482b22580171cc3fe6fdff189ccc2516_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2909018ece19f4bbf41657f9e44db7e8482b22580171cc3fe6fdff189ccc2516->leave($__internal_2909018ece19f4bbf41657f9e44db7e8482b22580171cc3fe6fdff189ccc2516_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_39a484af277a1ba6c099936857e6cf5b711a9956a01482b2367517bdd64cffe3 = $this->env->getExtension("native_profiler");
        $__internal_39a484af277a1ba6c099936857e6cf5b711a9956a01482b2367517bdd64cffe3->enter($__internal_39a484af277a1ba6c099936857e6cf5b711a9956a01482b2367517bdd64cffe3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_39a484af277a1ba6c099936857e6cf5b711a9956a01482b2367517bdd64cffe3->leave($__internal_39a484af277a1ba6c099936857e6cf5b711a9956a01482b2367517bdd64cffe3_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_2810772a6b6f3e0f9efb8789323b65d9f32bb22e93272b8375bab46b8cd2be74 = $this->env->getExtension("native_profiler");
        $__internal_2810772a6b6f3e0f9efb8789323b65d9f32bb22e93272b8375bab46b8cd2be74->enter($__internal_2810772a6b6f3e0f9efb8789323b65d9f32bb22e93272b8375bab46b8cd2be74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_2810772a6b6f3e0f9efb8789323b65d9f32bb22e93272b8375bab46b8cd2be74->leave($__internal_2810772a6b6f3e0f9efb8789323b65d9f32bb22e93272b8375bab46b8cd2be74_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
