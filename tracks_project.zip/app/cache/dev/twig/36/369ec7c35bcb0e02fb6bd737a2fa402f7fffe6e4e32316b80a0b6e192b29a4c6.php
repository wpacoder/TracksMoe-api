<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_d66c71af49dcd8ecfb0d58772303fe3b49664c47f594c7b8057049fcde136af4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ade206ee0f81216e1156dd01be9eaa90fde822366ab850f8b627a83832ba0679 = $this->env->getExtension("native_profiler");
        $__internal_ade206ee0f81216e1156dd01be9eaa90fde822366ab850f8b627a83832ba0679->enter($__internal_ade206ee0f81216e1156dd01be9eaa90fde822366ab850f8b627a83832ba0679_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_ade206ee0f81216e1156dd01be9eaa90fde822366ab850f8b627a83832ba0679->leave($__internal_ade206ee0f81216e1156dd01be9eaa90fde822366ab850f8b627a83832ba0679_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
