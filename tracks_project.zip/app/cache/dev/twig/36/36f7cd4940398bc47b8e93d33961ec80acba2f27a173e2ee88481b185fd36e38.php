<?php

/* @TracksAPI/Default/albumlist.html.twig */
class __TwigTemplate_ac36f509eccb928fb2b4760ee078cda2a47a8853534ac8258dfabe742c7890bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "@TracksAPI/Default/albumlist.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a578e29ef6575356cf3aa6a322068a8f3348fffb0462b675a72c400754484c8b = $this->env->getExtension("native_profiler");
        $__internal_a578e29ef6575356cf3aa6a322068a8f3348fffb0462b675a72c400754484c8b->enter($__internal_a578e29ef6575356cf3aa6a322068a8f3348fffb0462b675a72c400754484c8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@TracksAPI/Default/albumlist.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a578e29ef6575356cf3aa6a322068a8f3348fffb0462b675a72c400754484c8b->leave($__internal_a578e29ef6575356cf3aa6a322068a8f3348fffb0462b675a72c400754484c8b_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_b98969d06a1f6f7632c7a7298ff6a963ad01bc99287e6f7b367841d1887fb359 = $this->env->getExtension("native_profiler");
        $__internal_b98969d06a1f6f7632c7a7298ff6a963ad01bc99287e6f7b367841d1887fb359->enter($__internal_b98969d06a1f6f7632c7a7298ff6a963ad01bc99287e6f7b367841d1887fb359_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Album List";
        
        $__internal_b98969d06a1f6f7632c7a7298ff6a963ad01bc99287e6f7b367841d1887fb359->leave($__internal_b98969d06a1f6f7632c7a7298ff6a963ad01bc99287e6f7b367841d1887fb359_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_27972dec4a39ccef38cc7cd1ee157418ddaf5981762ba5d20e7c50129173080b = $this->env->getExtension("native_profiler");
        $__internal_27972dec4a39ccef38cc7cd1ee157418ddaf5981762ba5d20e7c50129173080b->enter($__internal_27972dec4a39ccef38cc7cd1ee157418ddaf5981762ba5d20e7c50129173080b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Album List</h1>
<table border=\"1\">
";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["albumlistdata"]) ? $context["albumlistdata"] : $this->getContext($context, "albumlistdata")));
        foreach ($context['_seq'] as $context["row"] => $context["columns"]) {
            // line 9
            echo "\t</tr>
\t\t";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["columns"]);
            foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                // line 11
                echo "\t\t\t<td>";
                echo twig_escape_filter($this->env, $context["column"], "html", null, true);
                echo "</td>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "\t</tr>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['row'], $context['columns'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "</table>
";
        
        $__internal_27972dec4a39ccef38cc7cd1ee157418ddaf5981762ba5d20e7c50129173080b->leave($__internal_27972dec4a39ccef38cc7cd1ee157418ddaf5981762ba5d20e7c50129173080b_prof);

    }

    public function getTemplateName()
    {
        return "@TracksAPI/Default/albumlist.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 15,  77 => 13,  68 => 11,  64 => 10,  61 => 9,  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}Album List{% endblock %}*/
/* */
/* {% block body %}*/
/* <h1>Album List</h1>*/
/* <table border="1">*/
/* {% for row, columns in albumlistdata|raw %}*/
/* 	</tr>*/
/* 		{% for column in columns %}*/
/* 			<td>{{ column }}</td>*/
/* 		{% endfor %}*/
/* 	</tr>*/
/* 	{% endfor %}*/
/* </table>*/
/* {% endblock %}*/
