<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_1e1b2c6b16f3b2c7ef09f30513f293fe34056101d081bee145b396f9d361b152 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a46d12517817cfa260ecf766f2682d5d704bb270df1f2cd5656386ec70f9d6a3 = $this->env->getExtension("native_profiler");
        $__internal_a46d12517817cfa260ecf766f2682d5d704bb270df1f2cd5656386ec70f9d6a3->enter($__internal_a46d12517817cfa260ecf766f2682d5d704bb270df1f2cd5656386ec70f9d6a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_a46d12517817cfa260ecf766f2682d5d704bb270df1f2cd5656386ec70f9d6a3->leave($__internal_a46d12517817cfa260ecf766f2682d5d704bb270df1f2cd5656386ec70f9d6a3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
