<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_aa32448b279fe70140158d272ed1520a554a0f5464f97349d955d198f6c4d280 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_57a89423103b2788d0505b28ac3c01252b34d4f02212421ad9ff2ed036af470d = $this->env->getExtension("native_profiler");
        $__internal_57a89423103b2788d0505b28ac3c01252b34d4f02212421ad9ff2ed036af470d->enter($__internal_57a89423103b2788d0505b28ac3c01252b34d4f02212421ad9ff2ed036af470d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_57a89423103b2788d0505b28ac3c01252b34d4f02212421ad9ff2ed036af470d->leave($__internal_57a89423103b2788d0505b28ac3c01252b34d4f02212421ad9ff2ed036af470d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
