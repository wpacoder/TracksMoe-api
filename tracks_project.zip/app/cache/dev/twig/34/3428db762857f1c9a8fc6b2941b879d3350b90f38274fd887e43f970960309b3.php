<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_3c04fc8b68469967a13c19462b1634583e3dba6a15e28c1d29283f02e8ef9d5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a80ced1334d4120ea963f35ade268aba63470b61a9bb5ee31023a7f02404a1e8 = $this->env->getExtension("native_profiler");
        $__internal_a80ced1334d4120ea963f35ade268aba63470b61a9bb5ee31023a7f02404a1e8->enter($__internal_a80ced1334d4120ea963f35ade268aba63470b61a9bb5ee31023a7f02404a1e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_a80ced1334d4120ea963f35ade268aba63470b61a9bb5ee31023a7f02404a1e8->leave($__internal_a80ced1334d4120ea963f35ade268aba63470b61a9bb5ee31023a7f02404a1e8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
