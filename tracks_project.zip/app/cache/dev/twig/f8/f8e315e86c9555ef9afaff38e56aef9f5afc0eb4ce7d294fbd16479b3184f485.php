<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_f7b560842ff18fa8435155c98a7767acf1b103cb5d9989ab0e051610aea13a27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0e807483328d38904b33fe33a3b0f4eafac98cc352a83cebdf69bd07e3c51959 = $this->env->getExtension("native_profiler");
        $__internal_0e807483328d38904b33fe33a3b0f4eafac98cc352a83cebdf69bd07e3c51959->enter($__internal_0e807483328d38904b33fe33a3b0f4eafac98cc352a83cebdf69bd07e3c51959_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_0e807483328d38904b33fe33a3b0f4eafac98cc352a83cebdf69bd07e3c51959->leave($__internal_0e807483328d38904b33fe33a3b0f4eafac98cc352a83cebdf69bd07e3c51959_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
