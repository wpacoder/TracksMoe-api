<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_d283c43add18d1197526e48a85e2aeeb67200f9bc6c6213e91eea00bed4feca3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cbcb0b45b1e38d63ed2978ec657d8d86d36f8a2458db9f656f5e397a56f0e9ac = $this->env->getExtension("native_profiler");
        $__internal_cbcb0b45b1e38d63ed2978ec657d8d86d36f8a2458db9f656f5e397a56f0e9ac->enter($__internal_cbcb0b45b1e38d63ed2978ec657d8d86d36f8a2458db9f656f5e397a56f0e9ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_cbcb0b45b1e38d63ed2978ec657d8d86d36f8a2458db9f656f5e397a56f0e9ac->leave($__internal_cbcb0b45b1e38d63ed2978ec657d8d86d36f8a2458db9f656f5e397a56f0e9ac_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
