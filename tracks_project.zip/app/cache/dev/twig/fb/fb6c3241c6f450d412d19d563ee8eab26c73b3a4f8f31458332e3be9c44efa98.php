<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_ed0ae2f11c9690ed2c00cd28ccb5f41be90926be14319b847bf9ac3eeae902f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c4b9e80eaa695fb547dad8022246a36bdc7a0d0839c80189c84088f821bda93f = $this->env->getExtension("native_profiler");
        $__internal_c4b9e80eaa695fb547dad8022246a36bdc7a0d0839c80189c84088f821bda93f->enter($__internal_c4b9e80eaa695fb547dad8022246a36bdc7a0d0839c80189c84088f821bda93f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_c4b9e80eaa695fb547dad8022246a36bdc7a0d0839c80189c84088f821bda93f->leave($__internal_c4b9e80eaa695fb547dad8022246a36bdc7a0d0839c80189c84088f821bda93f_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */
