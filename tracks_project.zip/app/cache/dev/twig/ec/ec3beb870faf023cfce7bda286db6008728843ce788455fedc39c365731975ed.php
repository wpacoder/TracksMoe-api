<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_90596a5407bc4ba6af7dde86ac26094c452feb896a390432d0bd8dfbd9d69b2a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_49fd5d015afad17953ab31aedfb8876a33c40ec3b0aabeba2dc927b1df939f81 = $this->env->getExtension("native_profiler");
        $__internal_49fd5d015afad17953ab31aedfb8876a33c40ec3b0aabeba2dc927b1df939f81->enter($__internal_49fd5d015afad17953ab31aedfb8876a33c40ec3b0aabeba2dc927b1df939f81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_49fd5d015afad17953ab31aedfb8876a33c40ec3b0aabeba2dc927b1df939f81->leave($__internal_49fd5d015afad17953ab31aedfb8876a33c40ec3b0aabeba2dc927b1df939f81_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
