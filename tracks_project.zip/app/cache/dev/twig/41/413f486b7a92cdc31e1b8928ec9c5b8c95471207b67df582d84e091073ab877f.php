<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_1847be9d744a769161c040445a11e548d65b757554e5bc79c39f5a9f32714b3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fdca3fececf03cf2ede0f48225d890390983255ba0b705081e2d22f1c5d9400 = $this->env->getExtension("native_profiler");
        $__internal_9fdca3fececf03cf2ede0f48225d890390983255ba0b705081e2d22f1c5d9400->enter($__internal_9fdca3fececf03cf2ede0f48225d890390983255ba0b705081e2d22f1c5d9400_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_9fdca3fececf03cf2ede0f48225d890390983255ba0b705081e2d22f1c5d9400->leave($__internal_9fdca3fececf03cf2ede0f48225d890390983255ba0b705081e2d22f1c5d9400_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
