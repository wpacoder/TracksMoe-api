<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_aa2b52617f2bfa70a5e52b52d862bc27ac389cfe6ca5be74e92ae1313d47ce57 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1c154c46ced32c011f0464cf3ee6c33dd660eeb6a34c03efdfc518c27b99b51c = $this->env->getExtension("native_profiler");
        $__internal_1c154c46ced32c011f0464cf3ee6c33dd660eeb6a34c03efdfc518c27b99b51c->enter($__internal_1c154c46ced32c011f0464cf3ee6c33dd660eeb6a34c03efdfc518c27b99b51c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_1c154c46ced32c011f0464cf3ee6c33dd660eeb6a34c03efdfc518c27b99b51c->leave($__internal_1c154c46ced32c011f0464cf3ee6c33dd660eeb6a34c03efdfc518c27b99b51c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
