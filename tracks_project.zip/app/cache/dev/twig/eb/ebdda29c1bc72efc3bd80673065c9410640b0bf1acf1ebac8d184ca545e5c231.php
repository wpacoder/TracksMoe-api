<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_a2276058d04430563dad2cd09d9d52bb7a1f9b5119bab5d04354f6b8be16da02 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e3668b905928196c77e24e61e51ad9ca4dab47c5e2904f44f691481e5215f0f2 = $this->env->getExtension("native_profiler");
        $__internal_e3668b905928196c77e24e61e51ad9ca4dab47c5e2904f44f691481e5215f0f2->enter($__internal_e3668b905928196c77e24e61e51ad9ca4dab47c5e2904f44f691481e5215f0f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_e3668b905928196c77e24e61e51ad9ca4dab47c5e2904f44f691481e5215f0f2->leave($__internal_e3668b905928196c77e24e61e51ad9ca4dab47c5e2904f44f691481e5215f0f2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
