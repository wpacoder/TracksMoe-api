<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_d76b51505944a857b0b2aa258af6891ce6f004a2ca223dbcc678b9f530331090 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93dd06811a0af693b674363b1534d58be3d1ddfa36f428e11f94533f83fd46e8 = $this->env->getExtension("native_profiler");
        $__internal_93dd06811a0af693b674363b1534d58be3d1ddfa36f428e11f94533f83fd46e8->enter($__internal_93dd06811a0af693b674363b1534d58be3d1ddfa36f428e11f94533f83fd46e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_93dd06811a0af693b674363b1534d58be3d1ddfa36f428e11f94533f83fd46e8->leave($__internal_93dd06811a0af693b674363b1534d58be3d1ddfa36f428e11f94533f83fd46e8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
