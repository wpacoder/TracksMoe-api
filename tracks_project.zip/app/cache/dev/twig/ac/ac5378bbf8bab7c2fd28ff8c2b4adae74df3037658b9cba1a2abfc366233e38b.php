<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_cf965ce1b146d60d99e69da9fb3fd5f8900c6cc47154796b57707b997f27c6ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c74e7f14f4b867af4c716a9760b450de17d816146223206e729974140446fc9 = $this->env->getExtension("native_profiler");
        $__internal_4c74e7f14f4b867af4c716a9760b450de17d816146223206e729974140446fc9->enter($__internal_4c74e7f14f4b867af4c716a9760b450de17d816146223206e729974140446fc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_4c74e7f14f4b867af4c716a9760b450de17d816146223206e729974140446fc9->leave($__internal_4c74e7f14f4b867af4c716a9760b450de17d816146223206e729974140446fc9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
