<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_118557ffd7b7ae795f928f7ea108b1c332fa1f9f3cbceb0fb615b760ee8f9a50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_64d456a8fbe3e7afe0094a3b06bdb256319e7aa5714b213c479c4aed60b90bb9 = $this->env->getExtension("native_profiler");
        $__internal_64d456a8fbe3e7afe0094a3b06bdb256319e7aa5714b213c479c4aed60b90bb9->enter($__internal_64d456a8fbe3e7afe0094a3b06bdb256319e7aa5714b213c479c4aed60b90bb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_64d456a8fbe3e7afe0094a3b06bdb256319e7aa5714b213c479c4aed60b90bb9->leave($__internal_64d456a8fbe3e7afe0094a3b06bdb256319e7aa5714b213c479c4aed60b90bb9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
