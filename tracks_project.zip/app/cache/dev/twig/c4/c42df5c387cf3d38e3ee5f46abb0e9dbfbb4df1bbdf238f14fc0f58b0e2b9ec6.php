<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_6f276d6a95033cc4125ff947205f5a33d09688e6b2848140347b28a122648167 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3351f0c567f26622564ce476f68c716553a655c98db18738de0f7de67b9c7058 = $this->env->getExtension("native_profiler");
        $__internal_3351f0c567f26622564ce476f68c716553a655c98db18738de0f7de67b9c7058->enter($__internal_3351f0c567f26622564ce476f68c716553a655c98db18738de0f7de67b9c7058_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_3351f0c567f26622564ce476f68c716553a655c98db18738de0f7de67b9c7058->leave($__internal_3351f0c567f26622564ce476f68c716553a655c98db18738de0f7de67b9c7058_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
