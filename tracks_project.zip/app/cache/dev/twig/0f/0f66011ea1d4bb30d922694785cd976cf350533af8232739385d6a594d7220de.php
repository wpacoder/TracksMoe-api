<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_9482c94d863538d0c9a1decbdf7177e8e7a37de09d5a2e758ef0e22425cd2b35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d5fe86184258d6fefc97abac6a48beacaee18e456a2a5586106f074913181632 = $this->env->getExtension("native_profiler");
        $__internal_d5fe86184258d6fefc97abac6a48beacaee18e456a2a5586106f074913181632->enter($__internal_d5fe86184258d6fefc97abac6a48beacaee18e456a2a5586106f074913181632_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_d5fe86184258d6fefc97abac6a48beacaee18e456a2a5586106f074913181632->leave($__internal_d5fe86184258d6fefc97abac6a48beacaee18e456a2a5586106f074913181632_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
