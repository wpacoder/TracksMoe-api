<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_3bd9a43c7c5244597049427fec87218d9a802d3590cf3ad52311302b3fc584bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa698004f27b91f7fbe5aaf8a18d0958da9fa8e8e3c49cbbc771aa9eee4d0366 = $this->env->getExtension("native_profiler");
        $__internal_fa698004f27b91f7fbe5aaf8a18d0958da9fa8e8e3c49cbbc771aa9eee4d0366->enter($__internal_fa698004f27b91f7fbe5aaf8a18d0958da9fa8e8e3c49cbbc771aa9eee4d0366_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_fa698004f27b91f7fbe5aaf8a18d0958da9fa8e8e3c49cbbc771aa9eee4d0366->leave($__internal_fa698004f27b91f7fbe5aaf8a18d0958da9fa8e8e3c49cbbc771aa9eee4d0366_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
