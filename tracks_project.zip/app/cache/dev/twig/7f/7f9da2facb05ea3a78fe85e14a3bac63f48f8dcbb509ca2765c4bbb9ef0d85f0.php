<?php

/* ::base.html.twig */
class __TwigTemplate_92676ea45de684937f446970b0145606f513a30eb6ffdb710d4fd989fe5032d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12d62d58d78982376b99d7214c4f0d6b9e2b4c75c03b0677f374293c9dcac370 = $this->env->getExtension("native_profiler");
        $__internal_12d62d58d78982376b99d7214c4f0d6b9e2b4c75c03b0677f374293c9dcac370->enter($__internal_12d62d58d78982376b99d7214c4f0d6b9e2b4c75c03b0677f374293c9dcac370_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_12d62d58d78982376b99d7214c4f0d6b9e2b4c75c03b0677f374293c9dcac370->leave($__internal_12d62d58d78982376b99d7214c4f0d6b9e2b4c75c03b0677f374293c9dcac370_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_5753f134eb88d30d2cc3234c64c655c08219b83daf4ab6e18cd1d94509485a1f = $this->env->getExtension("native_profiler");
        $__internal_5753f134eb88d30d2cc3234c64c655c08219b83daf4ab6e18cd1d94509485a1f->enter($__internal_5753f134eb88d30d2cc3234c64c655c08219b83daf4ab6e18cd1d94509485a1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_5753f134eb88d30d2cc3234c64c655c08219b83daf4ab6e18cd1d94509485a1f->leave($__internal_5753f134eb88d30d2cc3234c64c655c08219b83daf4ab6e18cd1d94509485a1f_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3a63a14cdb3dab708cd5c78ec0ce7cdf3ca175094a5ef291b7d17962e1c2f1a7 = $this->env->getExtension("native_profiler");
        $__internal_3a63a14cdb3dab708cd5c78ec0ce7cdf3ca175094a5ef291b7d17962e1c2f1a7->enter($__internal_3a63a14cdb3dab708cd5c78ec0ce7cdf3ca175094a5ef291b7d17962e1c2f1a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_3a63a14cdb3dab708cd5c78ec0ce7cdf3ca175094a5ef291b7d17962e1c2f1a7->leave($__internal_3a63a14cdb3dab708cd5c78ec0ce7cdf3ca175094a5ef291b7d17962e1c2f1a7_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_fb36a7edf8b200f5dbe0caaacf6d82cc0a400d4213ed365b3046c87e8238a05a = $this->env->getExtension("native_profiler");
        $__internal_fb36a7edf8b200f5dbe0caaacf6d82cc0a400d4213ed365b3046c87e8238a05a->enter($__internal_fb36a7edf8b200f5dbe0caaacf6d82cc0a400d4213ed365b3046c87e8238a05a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_fb36a7edf8b200f5dbe0caaacf6d82cc0a400d4213ed365b3046c87e8238a05a->leave($__internal_fb36a7edf8b200f5dbe0caaacf6d82cc0a400d4213ed365b3046c87e8238a05a_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5ec3a43e048da23951a2d41a7a7574e21d4a4a6a48381075eb9744acd6242309 = $this->env->getExtension("native_profiler");
        $__internal_5ec3a43e048da23951a2d41a7a7574e21d4a4a6a48381075eb9744acd6242309->enter($__internal_5ec3a43e048da23951a2d41a7a7574e21d4a4a6a48381075eb9744acd6242309_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_5ec3a43e048da23951a2d41a7a7574e21d4a4a6a48381075eb9744acd6242309->leave($__internal_5ec3a43e048da23951a2d41a7a7574e21d4a4a6a48381075eb9744acd6242309_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
