<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_9b9082300830dd3076a539dd35bbd88a206cfe8872e314c88e7620478200a5eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f9f58cb902e3e9c6dc11ba2772e1fb167d17de8cb765c1cb24e44d055aef366 = $this->env->getExtension("native_profiler");
        $__internal_7f9f58cb902e3e9c6dc11ba2772e1fb167d17de8cb765c1cb24e44d055aef366->enter($__internal_7f9f58cb902e3e9c6dc11ba2772e1fb167d17de8cb765c1cb24e44d055aef366_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_7f9f58cb902e3e9c6dc11ba2772e1fb167d17de8cb765c1cb24e44d055aef366->leave($__internal_7f9f58cb902e3e9c6dc11ba2772e1fb167d17de8cb765c1cb24e44d055aef366_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
