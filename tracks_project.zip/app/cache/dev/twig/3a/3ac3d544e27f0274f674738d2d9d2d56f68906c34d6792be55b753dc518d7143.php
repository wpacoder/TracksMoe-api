<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_41983f5253d92ffbeece1d42b0ef86b7afd0727737723bd017dece6019c0de8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7360507075d3308c0783b997ae294be92eeb7c860b23d50778b76f766da22398 = $this->env->getExtension("native_profiler");
        $__internal_7360507075d3308c0783b997ae294be92eeb7c860b23d50778b76f766da22398->enter($__internal_7360507075d3308c0783b997ae294be92eeb7c860b23d50778b76f766da22398_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_7360507075d3308c0783b997ae294be92eeb7c860b23d50778b76f766da22398->leave($__internal_7360507075d3308c0783b997ae294be92eeb7c860b23d50778b76f766da22398_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
