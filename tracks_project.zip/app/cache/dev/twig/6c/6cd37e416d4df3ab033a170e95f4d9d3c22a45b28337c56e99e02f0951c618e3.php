<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_2a4c207b3665e36d8c0b0740e0dd031e35a40e3a38d14b2230f65727d2ca0621 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66bad546a131abfa407000beb1f932fb1beedc63af88d51da957e2caafc784c4 = $this->env->getExtension("native_profiler");
        $__internal_66bad546a131abfa407000beb1f932fb1beedc63af88d51da957e2caafc784c4->enter($__internal_66bad546a131abfa407000beb1f932fb1beedc63af88d51da957e2caafc784c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_66bad546a131abfa407000beb1f932fb1beedc63af88d51da957e2caafc784c4->leave($__internal_66bad546a131abfa407000beb1f932fb1beedc63af88d51da957e2caafc784c4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
