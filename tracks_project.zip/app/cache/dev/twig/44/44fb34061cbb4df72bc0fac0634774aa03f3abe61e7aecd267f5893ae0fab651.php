<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_3195570093cfbd48145ae475ee9e8723283315c6436094955f34820bea104ff6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba1e40194833d8cf4dbd5c0929387ecf0866535360b53c66a28f8549e55a2e2b = $this->env->getExtension("native_profiler");
        $__internal_ba1e40194833d8cf4dbd5c0929387ecf0866535360b53c66a28f8549e55a2e2b->enter($__internal_ba1e40194833d8cf4dbd5c0929387ecf0866535360b53c66a28f8549e55a2e2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_ba1e40194833d8cf4dbd5c0929387ecf0866535360b53c66a28f8549e55a2e2b->leave($__internal_ba1e40194833d8cf4dbd5c0929387ecf0866535360b53c66a28f8549e55a2e2b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
