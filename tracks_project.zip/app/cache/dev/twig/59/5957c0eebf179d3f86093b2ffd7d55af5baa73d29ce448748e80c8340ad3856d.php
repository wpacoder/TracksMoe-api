<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_8f5357e6dae64c9360e02f33077e370bc7d912ecad6b5bda9b2c21c69d0d24bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1ef65e2c0febff4f8ba905615a1a3ef26bb7e037e11eb006abb7dc183be26542 = $this->env->getExtension("native_profiler");
        $__internal_1ef65e2c0febff4f8ba905615a1a3ef26bb7e037e11eb006abb7dc183be26542->enter($__internal_1ef65e2c0febff4f8ba905615a1a3ef26bb7e037e11eb006abb7dc183be26542_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_1ef65e2c0febff4f8ba905615a1a3ef26bb7e037e11eb006abb7dc183be26542->leave($__internal_1ef65e2c0febff4f8ba905615a1a3ef26bb7e037e11eb006abb7dc183be26542_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
