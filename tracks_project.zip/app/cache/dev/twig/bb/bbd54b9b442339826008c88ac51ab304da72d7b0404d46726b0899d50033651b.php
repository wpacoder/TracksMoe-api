<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_69a629604e12c9bc6fc498f677d273ea68085cb082d1dfececaaf4c5f7ec0437 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_910dc20fcce0aa55715144e306c1351d6dc3a84afdc7428a8ec1a6135fca3ef1 = $this->env->getExtension("native_profiler");
        $__internal_910dc20fcce0aa55715144e306c1351d6dc3a84afdc7428a8ec1a6135fca3ef1->enter($__internal_910dc20fcce0aa55715144e306c1351d6dc3a84afdc7428a8ec1a6135fca3ef1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_910dc20fcce0aa55715144e306c1351d6dc3a84afdc7428a8ec1a6135fca3ef1->leave($__internal_910dc20fcce0aa55715144e306c1351d6dc3a84afdc7428a8ec1a6135fca3ef1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
