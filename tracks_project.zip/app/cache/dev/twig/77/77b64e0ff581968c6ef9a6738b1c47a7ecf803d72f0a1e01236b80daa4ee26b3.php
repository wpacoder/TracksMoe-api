<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_863be3299f84a427c466be6ecebb36eb4af9ba99cb70d026a5925e30aca6f6fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4d821e0cf5c18e1c0c667aa8be4367c2d8023f494107b17d84604013f819f05f = $this->env->getExtension("native_profiler");
        $__internal_4d821e0cf5c18e1c0c667aa8be4367c2d8023f494107b17d84604013f819f05f->enter($__internal_4d821e0cf5c18e1c0c667aa8be4367c2d8023f494107b17d84604013f819f05f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_4d821e0cf5c18e1c0c667aa8be4367c2d8023f494107b17d84604013f819f05f->leave($__internal_4d821e0cf5c18e1c0c667aa8be4367c2d8023f494107b17d84604013f819f05f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
