<?php

/* @TracksAPI/Default/index.html.twig */
class __TwigTemplate_ee9b1dd90a42893056e97ecf9764f6ddf1f3046a9c4c6f2bb49eeef65cf23915 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_59bdf35f7992d3f337e419c78f8fbcc72449083b5684b9ad37828bfa32bf3b4b = $this->env->getExtension("native_profiler");
        $__internal_59bdf35f7992d3f337e419c78f8fbcc72449083b5684b9ad37828bfa32bf3b4b->enter($__internal_59bdf35f7992d3f337e419c78f8fbcc72449083b5684b9ad37828bfa32bf3b4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@TracksAPI/Default/index.html.twig"));

        // line 1
        echo "Hello World!
";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["catalog"]) ? $context["catalog"] : $this->getContext($context, "catalog")), 0, array(), "array"), "html", null, true);
        
        $__internal_59bdf35f7992d3f337e419c78f8fbcc72449083b5684b9ad37828bfa32bf3b4b->leave($__internal_59bdf35f7992d3f337e419c78f8fbcc72449083b5684b9ad37828bfa32bf3b4b_prof);

    }

    public function getTemplateName()
    {
        return "@TracksAPI/Default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* Hello World!*/
/* {{ catalog[0] }}*/
