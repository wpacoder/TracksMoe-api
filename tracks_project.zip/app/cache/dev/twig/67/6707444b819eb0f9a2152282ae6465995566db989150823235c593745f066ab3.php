<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_2e7c78dea8a4e97d298e150e90fb78dcde65259c9ce0371f17d4cdbed73c6add extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_159f3a4e6dbbef03f98ead3870c3591177d5ac140db00c0ec599e6de39a94025 = $this->env->getExtension("native_profiler");
        $__internal_159f3a4e6dbbef03f98ead3870c3591177d5ac140db00c0ec599e6de39a94025->enter($__internal_159f3a4e6dbbef03f98ead3870c3591177d5ac140db00c0ec599e6de39a94025_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_159f3a4e6dbbef03f98ead3870c3591177d5ac140db00c0ec599e6de39a94025->leave($__internal_159f3a4e6dbbef03f98ead3870c3591177d5ac140db00c0ec599e6de39a94025_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
