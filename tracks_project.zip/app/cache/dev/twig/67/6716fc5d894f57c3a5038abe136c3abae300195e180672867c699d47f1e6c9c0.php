<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_9bc8e3ffe60e1736cea42d4801d2a4b28ae0f2406df4765ca5c1bebd1915e951 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_21deb11bc8c92f0a6b10ca8d0a7b6f5d3e8d81bd560ff6538d90b6fa061af99d = $this->env->getExtension("native_profiler");
        $__internal_21deb11bc8c92f0a6b10ca8d0a7b6f5d3e8d81bd560ff6538d90b6fa061af99d->enter($__internal_21deb11bc8c92f0a6b10ca8d0a7b6f5d3e8d81bd560ff6538d90b6fa061af99d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_21deb11bc8c92f0a6b10ca8d0a7b6f5d3e8d81bd560ff6538d90b6fa061af99d->leave($__internal_21deb11bc8c92f0a6b10ca8d0a7b6f5d3e8d81bd560ff6538d90b6fa061af99d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
