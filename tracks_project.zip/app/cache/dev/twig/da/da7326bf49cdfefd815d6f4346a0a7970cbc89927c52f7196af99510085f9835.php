<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_d6e27b88117bb4e9a0d596e08adf55d326ec470a223950cefc9cd4aa961de50f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_930f75977effef8f0f32fe59fdd848980812c59f0942e3f848c7ff5c4b44c7ac = $this->env->getExtension("native_profiler");
        $__internal_930f75977effef8f0f32fe59fdd848980812c59f0942e3f848c7ff5c4b44c7ac->enter($__internal_930f75977effef8f0f32fe59fdd848980812c59f0942e3f848c7ff5c4b44c7ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_930f75977effef8f0f32fe59fdd848980812c59f0942e3f848c7ff5c4b44c7ac->leave($__internal_930f75977effef8f0f32fe59fdd848980812c59f0942e3f848c7ff5c4b44c7ac_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
