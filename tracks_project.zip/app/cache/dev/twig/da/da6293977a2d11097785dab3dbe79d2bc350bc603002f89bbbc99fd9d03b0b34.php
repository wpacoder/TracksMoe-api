<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_4f4e8fd93e85acb0e9a4ab753e61c3cafbcabdf0aad598529729caa88e3938a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a8d3d1d0e26cbf1362475189ac7019a49bf31b357e1ed88a344363decb40872 = $this->env->getExtension("native_profiler");
        $__internal_1a8d3d1d0e26cbf1362475189ac7019a49bf31b357e1ed88a344363decb40872->enter($__internal_1a8d3d1d0e26cbf1362475189ac7019a49bf31b357e1ed88a344363decb40872_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_1a8d3d1d0e26cbf1362475189ac7019a49bf31b357e1ed88a344363decb40872->leave($__internal_1a8d3d1d0e26cbf1362475189ac7019a49bf31b357e1ed88a344363decb40872_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */
