<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_3b7cce5eee64a9092c8b233210f97fdc52edf2edccbe7c62385be461fff411d5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_77a1335d4bbce9ad1943cb6b87a9306ff3e65c9e487e739a8905c9126336e57b = $this->env->getExtension("native_profiler");
        $__internal_77a1335d4bbce9ad1943cb6b87a9306ff3e65c9e487e739a8905c9126336e57b->enter($__internal_77a1335d4bbce9ad1943cb6b87a9306ff3e65c9e487e739a8905c9126336e57b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_77a1335d4bbce9ad1943cb6b87a9306ff3e65c9e487e739a8905c9126336e57b->leave($__internal_77a1335d4bbce9ad1943cb6b87a9306ff3e65c9e487e739a8905c9126336e57b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_93a80b7a74c0ac436a15b30f56c07762e2c3a7d2e3d6428ac45aedd1a5bd1fcb = $this->env->getExtension("native_profiler");
        $__internal_93a80b7a74c0ac436a15b30f56c07762e2c3a7d2e3d6428ac45aedd1a5bd1fcb->enter($__internal_93a80b7a74c0ac436a15b30f56c07762e2c3a7d2e3d6428ac45aedd1a5bd1fcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_93a80b7a74c0ac436a15b30f56c07762e2c3a7d2e3d6428ac45aedd1a5bd1fcb->leave($__internal_93a80b7a74c0ac436a15b30f56c07762e2c3a7d2e3d6428ac45aedd1a5bd1fcb_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_f87bc024de1120ef04400f7607fb5016c93326e792435bcb182591ca5b075985 = $this->env->getExtension("native_profiler");
        $__internal_f87bc024de1120ef04400f7607fb5016c93326e792435bcb182591ca5b075985->enter($__internal_f87bc024de1120ef04400f7607fb5016c93326e792435bcb182591ca5b075985_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_f87bc024de1120ef04400f7607fb5016c93326e792435bcb182591ca5b075985->leave($__internal_f87bc024de1120ef04400f7607fb5016c93326e792435bcb182591ca5b075985_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_5d054ded39e763c650237c0faa1c5e917a8d71d2e5b2a59fc5176f9f04b0c21c = $this->env->getExtension("native_profiler");
        $__internal_5d054ded39e763c650237c0faa1c5e917a8d71d2e5b2a59fc5176f9f04b0c21c->enter($__internal_5d054ded39e763c650237c0faa1c5e917a8d71d2e5b2a59fc5176f9f04b0c21c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_5d054ded39e763c650237c0faa1c5e917a8d71d2e5b2a59fc5176f9f04b0c21c->leave($__internal_5d054ded39e763c650237c0faa1c5e917a8d71d2e5b2a59fc5176f9f04b0c21c_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
