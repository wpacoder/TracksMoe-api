<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_617c37f3c2de8a5254bd0212411fe3cc9d7cc81e264451e87e4694ebe650a3bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f832ce7b8562ae5f6bf42e27a56b09c7ac1ca16d4055d063fbe07c7d3c715fd = $this->env->getExtension("native_profiler");
        $__internal_2f832ce7b8562ae5f6bf42e27a56b09c7ac1ca16d4055d063fbe07c7d3c715fd->enter($__internal_2f832ce7b8562ae5f6bf42e27a56b09c7ac1ca16d4055d063fbe07c7d3c715fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_2f832ce7b8562ae5f6bf42e27a56b09c7ac1ca16d4055d063fbe07c7d3c715fd->leave($__internal_2f832ce7b8562ae5f6bf42e27a56b09c7ac1ca16d4055d063fbe07c7d3c715fd_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */
