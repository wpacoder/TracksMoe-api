<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_0a8a64eff1e615f2d7585a9efeb157474e2159111a2c361b38fdd69053500ee4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f481bf74ff8d4b9165eda53a7ae88c4c148229be198109fb174626d43a9e59a4 = $this->env->getExtension("native_profiler");
        $__internal_f481bf74ff8d4b9165eda53a7ae88c4c148229be198109fb174626d43a9e59a4->enter($__internal_f481bf74ff8d4b9165eda53a7ae88c4c148229be198109fb174626d43a9e59a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_f481bf74ff8d4b9165eda53a7ae88c4c148229be198109fb174626d43a9e59a4->leave($__internal_f481bf74ff8d4b9165eda53a7ae88c4c148229be198109fb174626d43a9e59a4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
