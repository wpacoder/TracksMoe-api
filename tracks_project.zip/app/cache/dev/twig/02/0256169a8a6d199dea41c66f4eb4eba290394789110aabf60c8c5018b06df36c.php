<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_aa873e46995a2b08aa0fc51aa27606404c59a8f612d2db2c1fa546a46aee1d34 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04d2b2dcaa27b52055a298cab059bd28bc98e5e3cecb303558f86887722119f1 = $this->env->getExtension("native_profiler");
        $__internal_04d2b2dcaa27b52055a298cab059bd28bc98e5e3cecb303558f86887722119f1->enter($__internal_04d2b2dcaa27b52055a298cab059bd28bc98e5e3cecb303558f86887722119f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_04d2b2dcaa27b52055a298cab059bd28bc98e5e3cecb303558f86887722119f1->leave($__internal_04d2b2dcaa27b52055a298cab059bd28bc98e5e3cecb303558f86887722119f1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo str_replace('{{ widget }}', $view['form']->block($form, 'form_widget_simple'), $money_pattern) ?>*/
/* */
