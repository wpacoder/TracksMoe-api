<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_c4b7616d1ed3e5c313b14c48110132f2f2035b5e4cefe41c2534fdbcd60f07f7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d764b20049b4cb0fc75f4e04c2e52c92339cfd0770f77ce70058f8379e0d047 = $this->env->getExtension("native_profiler");
        $__internal_3d764b20049b4cb0fc75f4e04c2e52c92339cfd0770f77ce70058f8379e0d047->enter($__internal_3d764b20049b4cb0fc75f4e04c2e52c92339cfd0770f77ce70058f8379e0d047_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_3d764b20049b4cb0fc75f4e04c2e52c92339cfd0770f77ce70058f8379e0d047->leave($__internal_3d764b20049b4cb0fc75f4e04c2e52c92339cfd0770f77ce70058f8379e0d047_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
