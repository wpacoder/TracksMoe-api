<?php

/* TracksAPIBundle:Default:coba.html.twig */
class __TwigTemplate_3994c0339125c3201e909869bce2cdebe19daea8cab366a25a3a449b569475fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "TracksAPIBundle:Default:coba.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1629e906ee37b9a12179532d5840cff80fde762f9333d0a77bd2d31e7a783525 = $this->env->getExtension("native_profiler");
        $__internal_1629e906ee37b9a12179532d5840cff80fde762f9333d0a77bd2d31e7a783525->enter($__internal_1629e906ee37b9a12179532d5840cff80fde762f9333d0a77bd2d31e7a783525_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TracksAPIBundle:Default:coba.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1629e906ee37b9a12179532d5840cff80fde762f9333d0a77bd2d31e7a783525->leave($__internal_1629e906ee37b9a12179532d5840cff80fde762f9333d0a77bd2d31e7a783525_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_36787579c29f03eb04232cff213afc8484663d44e8ea3f16603a8869eb4a5e19 = $this->env->getExtension("native_profiler");
        $__internal_36787579c29f03eb04232cff213afc8484663d44e8ea3f16603a8869eb4a5e19->enter($__internal_36787579c29f03eb04232cff213afc8484663d44e8ea3f16603a8869eb4a5e19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "TracksAPIBundle:Coba:index";
        
        $__internal_36787579c29f03eb04232cff213afc8484663d44e8ea3f16603a8869eb4a5e19->leave($__internal_36787579c29f03eb04232cff213afc8484663d44e8ea3f16603a8869eb4a5e19_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_022b526d32723610a2d30eaab6f2c2b2e2e35e00f5810c11c257ebbfe8da0b0b = $this->env->getExtension("native_profiler");
        $__internal_022b526d32723610a2d30eaab6f2c2b2e2e35e00f5810c11c257ebbfe8da0b0b->enter($__internal_022b526d32723610a2d30eaab6f2c2b2e2e35e00f5810c11c257ebbfe8da0b0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Welcome to the Coba:index page </h1>
<table border=\"1\">
";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rows"]) ? $context["rows"] : $this->getContext($context, "rows")));
        foreach ($context['_seq'] as $context["row"] => $context["columns"]) {
            // line 9
            echo "\t</tr>
\t\t";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["columns"]);
            foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                // line 11
                echo "\t\t\t<td>";
                echo twig_escape_filter($this->env, $context["column"], "html", null, true);
                echo "</td>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "\t</tr>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['row'], $context['columns'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "</table>
";
        
        $__internal_022b526d32723610a2d30eaab6f2c2b2e2e35e00f5810c11c257ebbfe8da0b0b->leave($__internal_022b526d32723610a2d30eaab6f2c2b2e2e35e00f5810c11c257ebbfe8da0b0b_prof);

    }

    public function getTemplateName()
    {
        return "TracksAPIBundle:Default:coba.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 15,  77 => 13,  68 => 11,  64 => 10,  61 => 9,  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}TracksAPIBundle:Coba:index{% endblock %}*/
/* */
/* {% block body %}*/
/* <h1>Welcome to the Coba:index page </h1>*/
/* <table border="1">*/
/* {% for row, columns in rows %}*/
/* 	</tr>*/
/* 		{% for column in columns %}*/
/* 			<td>{{ column }}</td>*/
/* 			{% endfor %}*/
/* 	</tr>*/
/* 	{% endfor %}*/
/* </table>*/
/* {% endblock %}*/
