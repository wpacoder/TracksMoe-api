<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_394c6deec364482c06fa49750b74cdf9d47dc130569010dc878f0c1f5ff83752 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3660de22fa808e176323f08b81d039f7eafc2fe0c92be7acb29e8010e24edb24 = $this->env->getExtension("native_profiler");
        $__internal_3660de22fa808e176323f08b81d039f7eafc2fe0c92be7acb29e8010e24edb24->enter($__internal_3660de22fa808e176323f08b81d039f7eafc2fe0c92be7acb29e8010e24edb24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_3660de22fa808e176323f08b81d039f7eafc2fe0c92be7acb29e8010e24edb24->leave($__internal_3660de22fa808e176323f08b81d039f7eafc2fe0c92be7acb29e8010e24edb24_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
