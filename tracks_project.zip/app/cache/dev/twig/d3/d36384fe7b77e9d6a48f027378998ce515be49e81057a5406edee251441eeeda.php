<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_e8ee26106f8c11a693d2c0fb2e603abeb16d95d7b3fa438b68c9e0b4311f0716 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e9c02e131577d08e98a0b6a182bf8a3596fa641528ab75fbbddc27d8d290247d = $this->env->getExtension("native_profiler");
        $__internal_e9c02e131577d08e98a0b6a182bf8a3596fa641528ab75fbbddc27d8d290247d->enter($__internal_e9c02e131577d08e98a0b6a182bf8a3596fa641528ab75fbbddc27d8d290247d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_e9c02e131577d08e98a0b6a182bf8a3596fa641528ab75fbbddc27d8d290247d->leave($__internal_e9c02e131577d08e98a0b6a182bf8a3596fa641528ab75fbbddc27d8d290247d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child) : ?>*/
/*     <?php echo $view['form']->row($child) ?>*/
/* <?php endforeach; ?>*/
/* */
