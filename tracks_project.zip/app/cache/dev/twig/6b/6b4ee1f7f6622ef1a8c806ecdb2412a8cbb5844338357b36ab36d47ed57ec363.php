<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_6e1fabe47730fae3ebd3f1645820529f7c73b20a3def84b238ada0903008fe90 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "TwigBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cad2284ffc6dcc1bcd40484dacd7c38836c4ba50bbd34ff5d08dd05055426bad = $this->env->getExtension("native_profiler");
        $__internal_cad2284ffc6dcc1bcd40484dacd7c38836c4ba50bbd34ff5d08dd05055426bad->enter($__internal_cad2284ffc6dcc1bcd40484dacd7c38836c4ba50bbd34ff5d08dd05055426bad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cad2284ffc6dcc1bcd40484dacd7c38836c4ba50bbd34ff5d08dd05055426bad->leave($__internal_cad2284ffc6dcc1bcd40484dacd7c38836c4ba50bbd34ff5d08dd05055426bad_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_3ddf34117d75397d01a696cf365b4774f5bac7091f8b74c1d00ecdc6b31ad875 = $this->env->getExtension("native_profiler");
        $__internal_3ddf34117d75397d01a696cf365b4774f5bac7091f8b74c1d00ecdc6b31ad875->enter($__internal_3ddf34117d75397d01a696cf365b4774f5bac7091f8b74c1d00ecdc6b31ad875_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_3ddf34117d75397d01a696cf365b4774f5bac7091f8b74c1d00ecdc6b31ad875->leave($__internal_3ddf34117d75397d01a696cf365b4774f5bac7091f8b74c1d00ecdc6b31ad875_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_f9460ffe68e1edeaceb0ff5fb87f0f9bcd687b4a158a4fa7659822b02e63eb9b = $this->env->getExtension("native_profiler");
        $__internal_f9460ffe68e1edeaceb0ff5fb87f0f9bcd687b4a158a4fa7659822b02e63eb9b->enter($__internal_f9460ffe68e1edeaceb0ff5fb87f0f9bcd687b4a158a4fa7659822b02e63eb9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_f9460ffe68e1edeaceb0ff5fb87f0f9bcd687b4a158a4fa7659822b02e63eb9b->leave($__internal_f9460ffe68e1edeaceb0ff5fb87f0f9bcd687b4a158a4fa7659822b02e63eb9b_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_cc81d18c9daa09428138c7ce614af586e956015e844e80753e7b68150f3cba5f = $this->env->getExtension("native_profiler");
        $__internal_cc81d18c9daa09428138c7ce614af586e956015e844e80753e7b68150f3cba5f->enter($__internal_cc81d18c9daa09428138c7ce614af586e956015e844e80753e7b68150f3cba5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "TwigBundle:Exception:exception_full.html.twig", 12)->display($context);
        
        $__internal_cc81d18c9daa09428138c7ce614af586e956015e844e80753e7b68150f3cba5f->leave($__internal_cc81d18c9daa09428138c7ce614af586e956015e844e80753e7b68150f3cba5f_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block head %}*/
/*     <link href="{{ absolute_url(asset('bundles/framework/css/exception.css')) }}" rel="stylesheet" type="text/css" media="all" />*/
/* {% endblock %}*/
/* */
/* {% block title %}*/
/*     {{ exception.message }} ({{ status_code }} {{ status_text }})*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {% include '@Twig/Exception/exception.html.twig' %}*/
/* {% endblock %}*/
/* */
