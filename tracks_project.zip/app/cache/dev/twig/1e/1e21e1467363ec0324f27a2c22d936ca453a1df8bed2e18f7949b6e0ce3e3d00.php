<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_937cd126a975ef9bef60766a44d2bbc8a2be1357caf0e5ef15c9e6d183fa4953 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5892b68be67fcf94ae0382be1e1b3bcb67ffeed82e310cc09b7bd46779c8690f = $this->env->getExtension("native_profiler");
        $__internal_5892b68be67fcf94ae0382be1e1b3bcb67ffeed82e310cc09b7bd46779c8690f->enter($__internal_5892b68be67fcf94ae0382be1e1b3bcb67ffeed82e310cc09b7bd46779c8690f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_5892b68be67fcf94ae0382be1e1b3bcb67ffeed82e310cc09b7bd46779c8690f->leave($__internal_5892b68be67fcf94ae0382be1e1b3bcb67ffeed82e310cc09b7bd46779c8690f_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_79ddfabee2004879bfbd2a3121392e2d87ef0b8938d63a02ac1dfb4fa1c9d5a6 = $this->env->getExtension("native_profiler");
        $__internal_79ddfabee2004879bfbd2a3121392e2d87ef0b8938d63a02ac1dfb4fa1c9d5a6->enter($__internal_79ddfabee2004879bfbd2a3121392e2d87ef0b8938d63a02ac1dfb4fa1c9d5a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_79ddfabee2004879bfbd2a3121392e2d87ef0b8938d63a02ac1dfb4fa1c9d5a6->leave($__internal_79ddfabee2004879bfbd2a3121392e2d87ef0b8938d63a02ac1dfb4fa1c9d5a6_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
