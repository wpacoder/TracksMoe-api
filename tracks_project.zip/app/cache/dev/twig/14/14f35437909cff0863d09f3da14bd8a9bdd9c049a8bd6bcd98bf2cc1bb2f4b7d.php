<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_40f554933afb53b0a628e59c04f90e3da3d20241d9c7ee925f2b628e3c1d0818 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_696dfc13045ce4e52a6edeb0114984cfca3e6f5d5aa0b41c6270c20a7c76dcda = $this->env->getExtension("native_profiler");
        $__internal_696dfc13045ce4e52a6edeb0114984cfca3e6f5d5aa0b41c6270c20a7c76dcda->enter($__internal_696dfc13045ce4e52a6edeb0114984cfca3e6f5d5aa0b41c6270c20a7c76dcda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_696dfc13045ce4e52a6edeb0114984cfca3e6f5d5aa0b41c6270c20a7c76dcda->leave($__internal_696dfc13045ce4e52a6edeb0114984cfca3e6f5d5aa0b41c6270c20a7c76dcda_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
