<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_93262cf31c97b7ebad2c3e69e612ca9e48e2e8018d4bce97af255ba471da8934 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c1313602bca3a781dceaf042c99ac2935bb0df94106ef7c355e72f78bee5f5ec = $this->env->getExtension("native_profiler");
        $__internal_c1313602bca3a781dceaf042c99ac2935bb0df94106ef7c355e72f78bee5f5ec->enter($__internal_c1313602bca3a781dceaf042c99ac2935bb0df94106ef7c355e72f78bee5f5ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_c1313602bca3a781dceaf042c99ac2935bb0df94106ef7c355e72f78bee5f5ec->leave($__internal_c1313602bca3a781dceaf042c99ac2935bb0df94106ef7c355e72f78bee5f5ec_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_4cd1561c6ea736e6d6977fd9cbda71df23e2af82bbbe5aeb85e08dc3086d4fcd = $this->env->getExtension("native_profiler");
        $__internal_4cd1561c6ea736e6d6977fd9cbda71df23e2af82bbbe5aeb85e08dc3086d4fcd->enter($__internal_4cd1561c6ea736e6d6977fd9cbda71df23e2af82bbbe5aeb85e08dc3086d4fcd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_4cd1561c6ea736e6d6977fd9cbda71df23e2af82bbbe5aeb85e08dc3086d4fcd->leave($__internal_4cd1561c6ea736e6d6977fd9cbda71df23e2af82bbbe5aeb85e08dc3086d4fcd_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
