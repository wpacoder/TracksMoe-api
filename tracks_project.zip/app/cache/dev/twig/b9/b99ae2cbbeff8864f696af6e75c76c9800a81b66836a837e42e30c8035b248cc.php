<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_d30b8353dec13a99e57595de2871ec95b7899752f1bf8915ae97d246cc1c4ab2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1347c9d7225c6fe3a909ddd7b3ebd4354ce182cb8245b9807ac92ee122ec11ac = $this->env->getExtension("native_profiler");
        $__internal_1347c9d7225c6fe3a909ddd7b3ebd4354ce182cb8245b9807ac92ee122ec11ac->enter($__internal_1347c9d7225c6fe3a909ddd7b3ebd4354ce182cb8245b9807ac92ee122ec11ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_1347c9d7225c6fe3a909ddd7b3ebd4354ce182cb8245b9807ac92ee122ec11ac->leave($__internal_1347c9d7225c6fe3a909ddd7b3ebd4354ce182cb8245b9807ac92ee122ec11ac_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
