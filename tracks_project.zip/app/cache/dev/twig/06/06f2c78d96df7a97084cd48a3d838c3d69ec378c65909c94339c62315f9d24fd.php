<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_83ed255f292a4900f20d9ed5055dc555f88b8d44b4f6b12e6215d638e63b7886 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_207269a366f6c0649b2b83a37080d17517e756dd55c4e0d1686b8f6d1cac7d88 = $this->env->getExtension("native_profiler");
        $__internal_207269a366f6c0649b2b83a37080d17517e756dd55c4e0d1686b8f6d1cac7d88->enter($__internal_207269a366f6c0649b2b83a37080d17517e756dd55c4e0d1686b8f6d1cac7d88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_207269a366f6c0649b2b83a37080d17517e756dd55c4e0d1686b8f6d1cac7d88->leave($__internal_207269a366f6c0649b2b83a37080d17517e756dd55c4e0d1686b8f6d1cac7d88_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
