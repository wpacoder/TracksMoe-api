<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_8dfe41e397e9f20ea9578ac60f73cd1ae1ef903c6a69ed81880873c5fd29bbb7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a2d8ded49818e7506ae95caa614839744ced3e1e518fbec5c3f8ea4177688285 = $this->env->getExtension("native_profiler");
        $__internal_a2d8ded49818e7506ae95caa614839744ced3e1e518fbec5c3f8ea4177688285->enter($__internal_a2d8ded49818e7506ae95caa614839744ced3e1e518fbec5c3f8ea4177688285_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_a2d8ded49818e7506ae95caa614839744ced3e1e518fbec5c3f8ea4177688285->leave($__internal_a2d8ded49818e7506ae95caa614839744ced3e1e518fbec5c3f8ea4177688285_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
