<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_cb3cdbd92ca6893b7a764cc71b8ff37345d14a9fe7b2783da4cfd0e64d3acf99 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13437ea70de504d2938ec95d8afb9da36e7a43263ad066904db6639fb00f9796 = $this->env->getExtension("native_profiler");
        $__internal_13437ea70de504d2938ec95d8afb9da36e7a43263ad066904db6639fb00f9796->enter($__internal_13437ea70de504d2938ec95d8afb9da36e7a43263ad066904db6639fb00f9796_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_13437ea70de504d2938ec95d8afb9da36e7a43263ad066904db6639fb00f9796->leave($__internal_13437ea70de504d2938ec95d8afb9da36e7a43263ad066904db6639fb00f9796_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_c14043ba63c5628260b57e7bff208875fe0a825dd273ca22a62ba16b8db07467 = $this->env->getExtension("native_profiler");
        $__internal_c14043ba63c5628260b57e7bff208875fe0a825dd273ca22a62ba16b8db07467->enter($__internal_c14043ba63c5628260b57e7bff208875fe0a825dd273ca22a62ba16b8db07467_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_c14043ba63c5628260b57e7bff208875fe0a825dd273ca22a62ba16b8db07467->leave($__internal_c14043ba63c5628260b57e7bff208875fe0a825dd273ca22a62ba16b8db07467_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_2a8df9f8bed11c52b37c128be13fe8a2cd1591734d1148af120da05a125ef336 = $this->env->getExtension("native_profiler");
        $__internal_2a8df9f8bed11c52b37c128be13fe8a2cd1591734d1148af120da05a125ef336->enter($__internal_2a8df9f8bed11c52b37c128be13fe8a2cd1591734d1148af120da05a125ef336_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_2a8df9f8bed11c52b37c128be13fe8a2cd1591734d1148af120da05a125ef336->leave($__internal_2a8df9f8bed11c52b37c128be13fe8a2cd1591734d1148af120da05a125ef336_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_088726b36787a0615c46e8b03c39ef52d0843f99adb4444a2ad5cb478c8afa9a = $this->env->getExtension("native_profiler");
        $__internal_088726b36787a0615c46e8b03c39ef52d0843f99adb4444a2ad5cb478c8afa9a->enter($__internal_088726b36787a0615c46e8b03c39ef52d0843f99adb4444a2ad5cb478c8afa9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_088726b36787a0615c46e8b03c39ef52d0843f99adb4444a2ad5cb478c8afa9a->leave($__internal_088726b36787a0615c46e8b03c39ef52d0843f99adb4444a2ad5cb478c8afa9a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block head %}*/
/*     <link href="{{ absolute_url(asset('bundles/framework/css/exception.css')) }}" rel="stylesheet" type="text/css" media="all" />*/
/* {% endblock %}*/
/* */
/* {% block title %}*/
/*     {{ exception.message }} ({{ status_code }} {{ status_text }})*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {% include '@Twig/Exception/exception.html.twig' %}*/
/* {% endblock %}*/
/* */
