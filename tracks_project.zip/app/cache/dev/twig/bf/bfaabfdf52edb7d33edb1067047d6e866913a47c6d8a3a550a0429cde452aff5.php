<?php

/* @TracksAPI/Default/coba.html.twig */
class __TwigTemplate_baede243397b4384de1659d9dffae238e8d3c5080c858b2ced6a887c43aa0e91 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "@TracksAPI/Default/coba.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fb70dc16957b303f985622624d64158b4599f9da6e2498be7c36cede657371c = $this->env->getExtension("native_profiler");
        $__internal_2fb70dc16957b303f985622624d64158b4599f9da6e2498be7c36cede657371c->enter($__internal_2fb70dc16957b303f985622624d64158b4599f9da6e2498be7c36cede657371c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@TracksAPI/Default/coba.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2fb70dc16957b303f985622624d64158b4599f9da6e2498be7c36cede657371c->leave($__internal_2fb70dc16957b303f985622624d64158b4599f9da6e2498be7c36cede657371c_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_ad6a6a5246b1781e6cde75df86a65c2256bc34e4633d3d292e569d933e0191ce = $this->env->getExtension("native_profiler");
        $__internal_ad6a6a5246b1781e6cde75df86a65c2256bc34e4633d3d292e569d933e0191ce->enter($__internal_ad6a6a5246b1781e6cde75df86a65c2256bc34e4633d3d292e569d933e0191ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "TracksAPIBundle:Coba:index";
        
        $__internal_ad6a6a5246b1781e6cde75df86a65c2256bc34e4633d3d292e569d933e0191ce->leave($__internal_ad6a6a5246b1781e6cde75df86a65c2256bc34e4633d3d292e569d933e0191ce_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_775cc627da1e21ddfe996b7e4d6d9519322f7a71f9d398f9164b65b99fa0b5ef = $this->env->getExtension("native_profiler");
        $__internal_775cc627da1e21ddfe996b7e4d6d9519322f7a71f9d398f9164b65b99fa0b5ef->enter($__internal_775cc627da1e21ddfe996b7e4d6d9519322f7a71f9d398f9164b65b99fa0b5ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Welcome to the Coba:index page </h1>
<table border=\"1\">
";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rows"]) ? $context["rows"] : $this->getContext($context, "rows")));
        foreach ($context['_seq'] as $context["row"] => $context["columns"]) {
            // line 9
            echo "\t</tr>
\t\t";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["columns"]);
            foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                // line 11
                echo "\t\t\t<td>";
                echo twig_escape_filter($this->env, $context["column"], "html", null, true);
                echo "</td>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "\t</tr>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['row'], $context['columns'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "</table>
";
        
        $__internal_775cc627da1e21ddfe996b7e4d6d9519322f7a71f9d398f9164b65b99fa0b5ef->leave($__internal_775cc627da1e21ddfe996b7e4d6d9519322f7a71f9d398f9164b65b99fa0b5ef_prof);

    }

    public function getTemplateName()
    {
        return "@TracksAPI/Default/coba.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 15,  77 => 13,  68 => 11,  64 => 10,  61 => 9,  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}TracksAPIBundle:Coba:index{% endblock %}*/
/* */
/* {% block body %}*/
/* <h1>Welcome to the Coba:index page </h1>*/
/* <table border="1">*/
/* {% for row, columns in rows %}*/
/* 	</tr>*/
/* 		{% for column in columns %}*/
/* 			<td>{{ column }}</td>*/
/* 			{% endfor %}*/
/* 	</tr>*/
/* 	{% endfor %}*/
/* </table>*/
/* {% endblock %}*/
