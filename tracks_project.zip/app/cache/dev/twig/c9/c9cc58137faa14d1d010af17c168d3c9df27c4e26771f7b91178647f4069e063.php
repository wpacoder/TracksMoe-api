<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_535a0eb2035242916e1498c6312a3717500c726e43df8265d37046b5a297ab02 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b57f868ff1930e63218a099a6dc4b5d8f0c3a7273d2c939fdde31f77453db1d7 = $this->env->getExtension("native_profiler");
        $__internal_b57f868ff1930e63218a099a6dc4b5d8f0c3a7273d2c939fdde31f77453db1d7->enter($__internal_b57f868ff1930e63218a099a6dc4b5d8f0c3a7273d2c939fdde31f77453db1d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_b57f868ff1930e63218a099a6dc4b5d8f0c3a7273d2c939fdde31f77453db1d7->leave($__internal_b57f868ff1930e63218a099a6dc4b5d8f0c3a7273d2c939fdde31f77453db1d7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */
