<?php

/* TracksAPIBundle:Default:albumlist.html.twig */
class __TwigTemplate_804c3a292ef9450142b426fb12760453c4c4b63d5f4eb31618271b7464ce660e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "TracksAPIBundle:Default:albumlist.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e105b003467d3997fb303e440d33a284f4058063d9b67486d4b610ae3005b34 = $this->env->getExtension("native_profiler");
        $__internal_7e105b003467d3997fb303e440d33a284f4058063d9b67486d4b610ae3005b34->enter($__internal_7e105b003467d3997fb303e440d33a284f4058063d9b67486d4b610ae3005b34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TracksAPIBundle:Default:albumlist.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7e105b003467d3997fb303e440d33a284f4058063d9b67486d4b610ae3005b34->leave($__internal_7e105b003467d3997fb303e440d33a284f4058063d9b67486d4b610ae3005b34_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_1f352b7f8806f0fd9f7cf23cc546b357077f4d95b70bccee3d83f6c1a838f811 = $this->env->getExtension("native_profiler");
        $__internal_1f352b7f8806f0fd9f7cf23cc546b357077f4d95b70bccee3d83f6c1a838f811->enter($__internal_1f352b7f8806f0fd9f7cf23cc546b357077f4d95b70bccee3d83f6c1a838f811_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Album List";
        
        $__internal_1f352b7f8806f0fd9f7cf23cc546b357077f4d95b70bccee3d83f6c1a838f811->leave($__internal_1f352b7f8806f0fd9f7cf23cc546b357077f4d95b70bccee3d83f6c1a838f811_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_6c5535c21f84727fbc9beb12963c44cbad5857c4f00dad711b3e5ba0de479d39 = $this->env->getExtension("native_profiler");
        $__internal_6c5535c21f84727fbc9beb12963c44cbad5857c4f00dad711b3e5ba0de479d39->enter($__internal_6c5535c21f84727fbc9beb12963c44cbad5857c4f00dad711b3e5ba0de479d39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Album List</h1>
<table border=\"1\">
";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["albumlistdata"]) ? $context["albumlistdata"] : $this->getContext($context, "albumlistdata")));
        foreach ($context['_seq'] as $context["row"] => $context["columns"]) {
            // line 9
            echo "\t</tr>
\t\t";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["columns"]);
            foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                // line 11
                echo "\t\t\t<td>";
                echo twig_escape_filter($this->env, $context["column"], "html", null, true);
                echo "</td>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "\t</tr>
\t";
            // line 14
            flush();
            // line 15
            echo "\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['row'], $context['columns'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "</table>
";
        
        $__internal_6c5535c21f84727fbc9beb12963c44cbad5857c4f00dad711b3e5ba0de479d39->leave($__internal_6c5535c21f84727fbc9beb12963c44cbad5857c4f00dad711b3e5ba0de479d39_prof);

    }

    public function getTemplateName()
    {
        return "TracksAPIBundle:Default:albumlist.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 16,  82 => 15,  80 => 14,  77 => 13,  68 => 11,  64 => 10,  61 => 9,  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}Album List{% endblock %}*/
/* */
/* {% block body %}*/
/* <h1>Album List</h1>*/
/* <table border="1">*/
/* {% for row, columns in albumlistdata %}*/
/* 	</tr>*/
/* 		{% for column in columns %}*/
/* 			<td>{{ column }}</td>*/
/* 		{% endfor %}*/
/* 	</tr>*/
/* 	{% flush %}*/
/* 	{% endfor %}*/
/* </table>*/
/* {% endblock %}*/
