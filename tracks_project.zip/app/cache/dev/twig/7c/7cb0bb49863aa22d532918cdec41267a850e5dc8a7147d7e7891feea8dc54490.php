<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_2306728657b1342290a116df8db0e914d6d26211906eeae87fdf1b392b8805e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_698dbb2cc341358fb5909974bccf4bc34839d0898da0bf6fae803fe79b41f412 = $this->env->getExtension("native_profiler");
        $__internal_698dbb2cc341358fb5909974bccf4bc34839d0898da0bf6fae803fe79b41f412->enter($__internal_698dbb2cc341358fb5909974bccf4bc34839d0898da0bf6fae803fe79b41f412_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_698dbb2cc341358fb5909974bccf4bc34839d0898da0bf6fae803fe79b41f412->leave($__internal_698dbb2cc341358fb5909974bccf4bc34839d0898da0bf6fae803fe79b41f412_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
