<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_1c86330cd91df930d9de84e72de8cfffb8f88f05615f1c1698eb62b62619898f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aef69c931d0725dfc7bbffeec51ee365d56b68064d96074221455f789b62959c = $this->env->getExtension("native_profiler");
        $__internal_aef69c931d0725dfc7bbffeec51ee365d56b68064d96074221455f789b62959c->enter($__internal_aef69c931d0725dfc7bbffeec51ee365d56b68064d96074221455f789b62959c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_aef69c931d0725dfc7bbffeec51ee365d56b68064d96074221455f789b62959c->leave($__internal_aef69c931d0725dfc7bbffeec51ee365d56b68064d96074221455f789b62959c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */
