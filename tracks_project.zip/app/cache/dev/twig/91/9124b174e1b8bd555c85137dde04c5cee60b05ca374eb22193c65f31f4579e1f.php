<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_0716fc718b0c231687c1c23db191a2223583927d05e633a8bc267c0265a77bbb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fdeb922acf236b6d06760304f6609f2963cb7b3d0e945b7f75756c60e0175f50 = $this->env->getExtension("native_profiler");
        $__internal_fdeb922acf236b6d06760304f6609f2963cb7b3d0e945b7f75756c60e0175f50->enter($__internal_fdeb922acf236b6d06760304f6609f2963cb7b3d0e945b7f75756c60e0175f50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_fdeb922acf236b6d06760304f6609f2963cb7b3d0e945b7f75756c60e0175f50->leave($__internal_fdeb922acf236b6d06760304f6609f2963cb7b3d0e945b7f75756c60e0175f50_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
