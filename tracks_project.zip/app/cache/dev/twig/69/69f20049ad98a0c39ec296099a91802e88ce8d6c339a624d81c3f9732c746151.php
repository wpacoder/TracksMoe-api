<?php

/* TracksAPIBundle:Default:index.html.twig */
class __TwigTemplate_c4ee3abe2f6c40954d85c52b29a46a54ff16f412b839e33afc593b3ac24cefea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66fac1946ad93e4db26ddcbd9fb3c1650017c88ae97b799020266b4f76ed8688 = $this->env->getExtension("native_profiler");
        $__internal_66fac1946ad93e4db26ddcbd9fb3c1650017c88ae97b799020266b4f76ed8688->enter($__internal_66fac1946ad93e4db26ddcbd9fb3c1650017c88ae97b799020266b4f76ed8688_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TracksAPIBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["catalog"]) ? $context["catalog"] : $this->getContext($context, "catalog")), 0, array(), "array"), "html", null, true);
        
        $__internal_66fac1946ad93e4db26ddcbd9fb3c1650017c88ae97b799020266b4f76ed8688->leave($__internal_66fac1946ad93e4db26ddcbd9fb3c1650017c88ae97b799020266b4f76ed8688_prof);

    }

    public function getTemplateName()
    {
        return "TracksAPIBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* Hello World!*/
/* {{ catalog[0] }}*/
