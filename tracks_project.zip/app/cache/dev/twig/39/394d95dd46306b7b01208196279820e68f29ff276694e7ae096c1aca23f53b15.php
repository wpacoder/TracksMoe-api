<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_d3264c88b254f056b301d013ec78c8a91b6b21f41605b5723ca88a8b79b3f1b8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b0e3d627a5b4989e7b517d83ed5938b27063254295ff6a8b15b4c10b2e5c26f = $this->env->getExtension("native_profiler");
        $__internal_1b0e3d627a5b4989e7b517d83ed5938b27063254295ff6a8b15b4c10b2e5c26f->enter($__internal_1b0e3d627a5b4989e7b517d83ed5938b27063254295ff6a8b15b4c10b2e5c26f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_1b0e3d627a5b4989e7b517d83ed5938b27063254295ff6a8b15b4c10b2e5c26f->leave($__internal_1b0e3d627a5b4989e7b517d83ed5938b27063254295ff6a8b15b4c10b2e5c26f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
