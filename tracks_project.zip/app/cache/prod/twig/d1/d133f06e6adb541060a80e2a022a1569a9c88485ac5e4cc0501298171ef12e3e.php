<?php

/* TracksAPIBundle:Default:albumlist.html.twig */
class __TwigTemplate_af3c003420bdf8852682f52b241e640737692c1e2059b517aefb9ac11715b1e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "TracksAPIBundle:Default:albumlist.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Album List";
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "<h1>Album List</h1>
<table border=\"1\">
";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["albumlistdata"]) ? $context["albumlistdata"] : null));
        foreach ($context['_seq'] as $context["row"] => $context["columns"]) {
            // line 9
            echo "\t</tr>
\t\t";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["columns"]);
            foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                // line 11
                echo "\t\t\t<td>";
                echo twig_escape_filter($this->env, $context["column"], "html", null, true);
                echo "</td>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "\t</tr>
\t";
            // line 14
            flush();
            // line 15
            echo "\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['row'], $context['columns'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "</table>
";
    }

    public function getTemplateName()
    {
        return "TracksAPIBundle:Default:albumlist.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 16,  67 => 15,  65 => 14,  62 => 13,  53 => 11,  49 => 10,  46 => 9,  42 => 8,  38 => 6,  35 => 5,  29 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}Album List{% endblock %}*/
/* */
/* {% block body %}*/
/* <h1>Album List</h1>*/
/* <table border="1">*/
/* {% for row, columns in albumlistdata %}*/
/* 	</tr>*/
/* 		{% for column in columns %}*/
/* 			<td>{{ column }}</td>*/
/* 		{% endfor %}*/
/* 	</tr>*/
/* 	{% flush %}*/
/* 	{% endfor %}*/
/* </table>*/
/* {% endblock %}*/
