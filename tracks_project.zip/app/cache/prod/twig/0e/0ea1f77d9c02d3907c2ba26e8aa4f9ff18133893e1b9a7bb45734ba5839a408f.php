<?php

/* TracksAPIBundle:Default:index.html.twig */
class __TwigTemplate_7748e08258ad2103183f4aa5e790f8eb7a44602c71cc4f4cf18d160df104c474 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello World!
";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["catalog"]) ? $context["catalog"] : null), 0, array(), "array"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "TracksAPIBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 2,  19 => 1,);
    }
}
/* Hello World!*/
/* {{ catalog[0] }}*/
