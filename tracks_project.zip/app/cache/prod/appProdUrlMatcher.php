<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // tracks_api_albumlist_index
        if ($pathinfo === '/album') {
            return array (  '_controller' => 'Tracks\\APIBundle\\Controller\\AlbumListController::indexAction',  '_route' => 'tracks_api_albumlist_index',);
        }

        // tracks_api_coba_index
        if ($pathinfo === '/cobadom') {
            return array (  '_controller' => 'Tracks\\APIBundle\\Controller\\CobaController::indexAction',  '_route' => 'tracks_api_coba_index',);
        }

        // tracks_api_default_index
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'tracks_api_default_index');
            }

            return array (  '_controller' => 'Tracks\\APIBundle\\Controller\\DefaultController::indexAction',  '_route' => 'tracks_api_default_index',);
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
