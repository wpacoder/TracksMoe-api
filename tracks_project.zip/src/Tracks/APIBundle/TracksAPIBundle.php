<?php

namespace Tracks\APIBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TracksAPIBundle extends Bundle
{
}
