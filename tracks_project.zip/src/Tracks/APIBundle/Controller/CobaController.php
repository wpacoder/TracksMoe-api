<?php

namespace Tracks\APIBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\DomCrawler\Crawler;
use Symfony\Component\HttpFoundation\Response;
use Tracks\APIBundle\Parser\CobaDomParser;

class CobaController extends Controller
{

    /**
     * @Route("/cobadom")
     */
    public function indexAction()
    {	
        $update = CobaDomParser::parse();

        return $this->render('TracksAPIBundle:Default:coba.html.twig', array(
            'rows' => $update->getCatalog(),
        ));
    }

}
