<?php

namespace Tracks\APIBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Guzzle\Http\Exception;
use Tracks\APIBundle\Parser\AlbumListParser;
use JMS\Serializer\SerializationContext;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Tracks\APIBundle\Model\AlbumList;

class AlbumListController extends Controller
{
	
    /**
     * @Route("/album")
     */
    public function indexAction()
    {
    	$downloader = $this->get('tracks_api.communicator');
        $albumlistcontent = $downloader->fetch('/db/albums.php?ltr=K&field=title&perpage=999999');
        $albumlistparse = AlbumListParser::parse($albumlistcontent);

        return $this->render('TracksAPIBundle:Default:albumlist.html.twig', array(
            'albumlistdata'=>$albumlistparse->getCatalog(),
            ));
    }
}
