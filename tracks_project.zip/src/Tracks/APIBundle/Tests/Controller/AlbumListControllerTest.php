<?php

namespace Tracks\APIBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class AlbumListControllerTest extends WebTestCase
{
}
