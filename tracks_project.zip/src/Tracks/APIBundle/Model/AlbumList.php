<?php

namespace Tracks\APIBundle\Model;


class AlbumList
{
	 private $catalog = array();
	 private $title;
	 private $releaseDate;

	 public function setCatalog($catalog)
	 {
	 	$this->catalog = $catalog;
	 }

	 public function getCatalog()
	 {
	 	return $this->catalog;
	 }

	 public function setTitle($title)
	 {
	 	$this->title = $title;
	 }

	 public function getTitle()
	 {
	 	return $this->title;
	 }

	 public function setReleaseDate($releaseDate)
	 {
	 	$this->releaseDate = $releaseDate;
	 }

	 public function getReleaseDate()
	 {
	 	return $this->releaseDate;
	 } 
}