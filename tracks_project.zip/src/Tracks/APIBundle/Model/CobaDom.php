<?php

namespace Tracks\APIBundle\Model;

class CobaDom
{

	private $satu;

	public function setSatu($value)
	{
		$this->satu = $value;
	}

	/**
     * Get the title property.
     *
     * @return string
     */
	public function getSatu()
	{
		return $this->satu;
	}

	private $satusatu;

	public function setSatusatu($value)
	{
		$this->satusatu = $value;
	}

	/**
     * Get the title property.
     *
     * @return string
     */
	public function getSatusatu()
	{
		return $this->satusatu;
	}

	private $all = array();

	public function setAll($value)
	{
		$this->all = $value;
	}

	/**
     * Get the title property.
     *
     * @return array
     */
	public function getAll()
	{
		return $this->all;
	}

	private $catalog = array();

	public function setCatalog($value)
	{
		$this->catalog = $value;
	}

	/**
     * Get the title property.
     *
     * @return array
     */
	public function getCatalog()
	{
		return $this->catalog;
	}

	private $catalogItem;

	public function setCatalogItem($value)
	{
		$this->catalogItem = $value;
	}

	/**
     * Get the title property.
     *
     * @return array
     */
	public function getCatalogItem()
	{
		return $this->catalogItem;
	}
}