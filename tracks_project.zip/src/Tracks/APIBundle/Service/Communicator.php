<?php

namespace Tracks\APIBundle\Service;

use Symfony\Component\DomCrawler\Crawler;
use Guzzle\Http\Client;
use Guzzle\Http\Exception;
use Guzzle\Plugin\Cookie\CookiePlugin;
use Guzzle\Plugin\Cookie\CookieJar\ArrayCookieJar;

class Communicator
{
	private $useragent;
    private $baseurl;
    private $client;
    private $cookies;
    private $response;

    /**
    * Create an instance of the communicator.
    *
    * @param string $baseurl The base URL for the communications. Do not use a terminating slash.
    */
    public function __construct($baseurl, $ua)
    {
    	$this->useragent = $ua;
        $this->cookies = new CookiePlugin(new ArrayCookieJar());

        // create http client instance
        $this->client = new Client($baseurl);
        $this->client->addSubscriber($this->cookies);
    }

    /**
    * Fetch content from a URL
    *
    * @param string $url      Path to access
    *
    * @return string Contents of the resource at the supplied path.
    */
    public function fetch($url)
    {
        // create a request
        $request = $this->client->get($url);
        $request->setHeader('User-Agent', $this->useragent);

        // send request / get response
        $this->response = $request->send();

        // this is the response body from the requested page
        return $this->response->getBody();
    }
}