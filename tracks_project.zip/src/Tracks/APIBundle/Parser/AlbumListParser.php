<?php

namespace Tracks\APIBundle\Parser;

use Symfony\Component\DomCrawler\Crawler;
use Tracks\APIBundle\Model\AlbumList;

class AlbumListParser
{
	public static function parse($contents)
    {
    	$crawler = new Crawler();
        $crawler->addHTMLContent($contents, 'UTF-8');

        $albumlistdata = new AlbumList();

        $rows = array();
        $tr_elements = $crawler->filterXPath('//div[@id="innermain"]/div/table/tr');
        // iterate over filter results
        foreach ($tr_elements as $key => $content) {
            if($key === 0) continue;
            $tds = array();
            // create crawler instance for result
            $crawler = new Crawler($content);
            //iterate again
            foreach ($crawler->filter('td') as $node) {
               // extract the value
                $tds[] = $node->nodeValue;
            }
            $rows[] = $tds;
            $albumlistdata->setCatalog($rows);
        }

        return $albumlistdata;
    }
}