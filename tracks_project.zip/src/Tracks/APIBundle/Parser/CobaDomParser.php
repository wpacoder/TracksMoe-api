<?php

namespace Tracks\APIBundle\Parser;

use Symfony\Component\DomCrawler\Crawler;
use Symfony\Component\CssSelector\Selector;
use Tracks\APIBundle\Model\CobaDom;
use DomXpath;

class CobaDomParser
{
	public static function parse()
	{
		$html = <<<'HTML'
		<!DOCTYPE html>
		<html>
    		<body>
        		<table class="oop" cellpadding="0" cellspacing="0" border="0" align="left" width="100%">
					<tr>
						<td class="thead" nowrap="nowrap"><a href="../db/albums.php?ltr=A&amp;field=cn&amp;perpage=999999"><h4>CATALOG</h4></a></td>
						<td class="thead">&nbsp;</td>
						<td class="thead" width="75%"><a href="../db/albums.php?ltr=A&amp;field=title&amp;perpage=999999"><h4>ALBUM TITLE</h4></a></td>
						<td class="thead" style="text-align: right" nowrap="nowrap"><h4>COY</h4></td>
					</tr>
					<tr>
						<td class="thead" nowrap="nowrap"><a href="../db/albums.php?ltr=A&amp;field=cn&amp;perpage=999999"><h4>CATALOG</h4></a></td>
						<td class="thead">&nbsp;</td>
						<td class="thead" width="75%"><a href="../db/albums.php?ltr=A&amp;field=title&amp;perpage=999999"><h4>ALBUM TITLE</h4></a></td>
						<td class="thead" style="text-align: right" nowrap="nowrap"><h4>RELEASE DATE</h4></td>
					</tr>
					<tr>
						<td class="thead" nowrap="nowrap"><a href="../db/albums.php?ltr=A&amp;field=cn&amp;perpage=999999"><h4>CATALOG</h4></a></td>
						<td class="thead">&nbsp;</td>
						<td class="thead" width="75%"><a href="../db/albums.php?ltr=A&amp;field=title&amp;perpage=999999"><h4>ALBUM TITLE</h4></a></td>
						<td class="thead" style="text-align: right" nowrap="nowrap"><h4>RELEASE DATE</h4></td>
					</tr>
					
				</table>
        		
    		</body>
		</html>
HTML;
		$data = new CobaDom();
		$crawler = new Crawler();
		$crawler->addHTMLContent($html);
  		$rows = array();
	    $tr_elements = $crawler->filterXPath('//table/tr');
	    // iterate over filter results
	    foreach ($tr_elements as $content) {
	        $tds = array();
	        // create crawler instance for result
	        $crawler = new Crawler($content);
	        //iterate again
	        foreach ($crawler->filter('td') as $node) {
	           // extract the value
	            $tds[] = $node->nodeValue;
	        }
	        $rows[] = $tds;
	        $data->setCatalog($rows);
	    }
		return $data;
	}
}